﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_image_img = ''
        let normal_cal_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '011.png',
              center_x: 231,
              center_y: 119,
              x: 8,
              y: 93,
              start_angle: 224,
              end_angle: 494,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '007.png',
              center_x: 97,
              center_y: 232,
              x: 13,
              y: 50,
              start_angle: 360,
              end_angle: 0,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '011.png',
              center_x: 232,
              center_y: 349,
              x: 8,
              y: 91,
              start_angle: 224,
              end_angle: 495,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 328,
              font_array: ["T_01.png","T_02.png","T_03.png","T_04.png","T_05.png","T_06.png","T_07.png","T_08.png","T_09.png","T_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 83,
              image_array: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png","W_08.png","W_09.png","W_10.png","W_11.png","W_12.png","W_13.png","W_14.png","W_15.png","W_16.png","W_17.png","W_18.png","W_19.png","W_20.png","W_21.png","W_22.png","W_23.png","W_24.png","W_25.png","W_26.png","W_27.png","W_28.png","W_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 140,
              font_array: ["T_01.png","T_02.png","T_03.png","T_04.png","T_05.png","T_06.png","T_07.png","T_08.png","T_09.png","T_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'T_13.png',
              unit_tc: 'T_13.png',
              unit_en: 'T_13.png',
              negative_image: 'T_12.png',
              invalid_image: 'T_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 301,
              y: 217,
              src: 'BT_Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 339,
              y: 105,
              week_en: ["D_01.png","D_02.png","D_03.png","D_04.png","D_05.png","D_06.png","D_07.png"],
              week_tc: ["D_01.png","D_02.png","D_03.png","D_04.png","D_05.png","D_06.png","D_07.png"],
              week_sc: ["D_01.png","D_02.png","D_03.png","D_04.png","D_05.png","D_06.png","D_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 312,
              day_startY: 224,
              day_sc_array: ["S_01.png","S_02.png","S_03.png","S_04.png","S_05.png","S_06.png","S_07.png","S_08.png","S_09.png","S_10.png"],
              day_tc_array: ["S_01.png","S_02.png","S_03.png","S_04.png","S_05.png","S_06.png","S_07.png","S_08.png","S_09.png","S_10.png"],
              day_en_array: ["S_01.png","S_02.png","S_03.png","S_04.png","S_05.png","S_06.png","S_07.png","S_08.png","S_09.png","S_10.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '004.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 25,
              hour_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '005.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 25,
              minute_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '006.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 24,
              second_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '011.png',
              center_x: 231,
              center_y: 119,
              x: 8,
              y: 91,
              start_angle: 224,
              end_angle: 494,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '010.png',
              center_x: 97,
              center_y: 232,
              x: 13,
              y: 50,
              start_angle: 360,
              end_angle: 0,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '011.png',
              center_x: 232,
              center_y: 349,
              x: 8,
              y: 91,
              start_angle: 224,
              end_angle: 495,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 328,
              font_array: ["T_01.png","T_02.png","T_03.png","T_04.png","T_05.png","T_06.png","T_07.png","T_08.png","T_09.png","T_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 83,
              image_array: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png","W_08.png","W_09.png","W_10.png","W_11.png","W_12.png","W_13.png","W_14.png","W_15.png","W_16.png","W_17.png","W_18.png","W_19.png","W_20.png","W_21.png","W_22.png","W_23.png","W_24.png","W_25.png","W_26.png","W_27.png","W_28.png","W_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 140,
              font_array: ["T_01.png","T_02.png","T_03.png","T_04.png","T_05.png","T_06.png","T_07.png","T_08.png","T_09.png","T_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'T_13.png',
              unit_tc: 'T_13.png',
              unit_en: 'T_13.png',
              negative_image: 'T_12.png',
              invalid_image: 'T_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 213,
              src: 'BT_Off_2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 384,
              y: 222,
              week_en: ["D2_01.png","D2_02.png","D2_03.png","D2_04.png","D2_05.png","D2_06.png","D2_07.png"],
              week_tc: ["D2_01.png","D2_02.png","D2_03.png","D2_04.png","D2_05.png","D2_06.png","D2_07.png"],
              week_sc: ["D2_01.png","D2_02.png","D2_03.png","D2_04.png","D2_05.png","D2_06.png","D2_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 316,
              day_startY: 227,
              day_sc_array: ["T_01.png","T_02.png","T_03.png","T_04.png","T_05.png","T_06.png","T_07.png","T_08.png","T_09.png","T_10.png"],
              day_tc_array: ["T_01.png","T_02.png","T_03.png","T_04.png","T_05.png","T_06.png","T_07.png","T_08.png","T_09.png","T_10.png"],
              day_en_array: ["T_01.png","T_02.png","T_03.png","T_04.png","T_05.png","T_06.png","T_07.png","T_08.png","T_09.png","T_10.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '004.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 25,
              hour_posY: 232,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '005.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 25,
              minute_posY: 232,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: 317,
              w: 100,
              h: 100,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 185,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 61,
              w: 100,
              h: 100,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 349,
              y: 130,
              w: 100,
              h: 207,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}

//#region Loading data from RuWeather
        function arrayBufferToCyrillic(buffer) {
          const bytes = new Uint8Array(buffer);
      const len = bytes.length;
      let chars = [];

      for (let i = 0; i < len;) {
        const byte1 = bytes[i];

        if (byte1 < 0x80) {
          chars.push(byte1);
          i += 1;
        } else if (byte1 >= 0xC0 && byte1 < 0xE0) {
          const byte2 = bytes[i + 1];
          const code = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
          chars.push(code);
          i += 2;
        } else if (byte1 >= 0xE0 && byte1 < 0xF0) {
          const byte2 = bytes[i + 1];
          const byte3 = bytes[i + 2];
          const code = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
          chars.push(code);
          i += 3;
        } else {
          // Skip invalid byte
          i++;
        }
      }

      // Вставка батчами для ускорения
      let result = '';
      const chunkSize = 1024;
      for (let j = 0; j < chars.length; j += chunkSize) {
        result += String.fromCharCode.apply(null, chars.slice(j, j + chunkSize));
      }

      return result;
        }
        function read_weather_data_str() {
          console.log('start read weather data');
          let str_result = "";
          try {
            const file_name = "weather.json";
            const mini_app_id = 1066654;

            const [fs_stat, err] = hmFS.stat(file_name, {
              appid: mini_app_id
            });
            if (err == 0) {
              //console.log('--->size_alt:', fs_stat.size);

              const fh = hmFS.open(file_name, hmFS.O_RDONLY, {
                appid: mini_app_id
              })

              const len = fs_stat.size;
              let array_buffer = new ArrayBuffer(len);
              hmFS.read(fh, array_buffer, 0, len);
              hmFS.close(fh);
              str_result = arrayBufferToCyrillic(array_buffer);
              //console.log(`str_result = ${str_result}`);
              return str_result;

            } else {
              console.log('err:', err)
            }

          } catch (error) {
            console.log('error:', error);
            console.log("FAIL: No access to hmFS.");
          }
          return "";
        }
        function getDataValue(str = "") {
          let value = 0;
          try {
            const data = JSON.parse(str); //получаем массив данных
            //присваиваем виджетам их значения
            normal_temperature_current_text_font.setProperty(hmUI.prop.TEXT, data.temperature + '°') //присваиваем виджетам их значения
            idle_temperature_current_text_font.setProperty(hmUI.prop.TEXT, data.temperature + '°')

            wCurTemp.setProperty(hmUI.prop.TEXT, data.temperature + '°(' + data.temperatureFeels + '°)')
            wCity.setProperty(hmUI.prop.TEXT, data.city)
            wUpdate.setProperty(hmUI.prop.TEXT, data.weatherTimeStr)

          } catch (error) {
            console.log('error:', error);
          }

        }

        function updateWeatherApp() {
          console.log('tick')
          let read_str = read_weather_data_str();
          getDataValue(read_str);
        }
        //#endregion