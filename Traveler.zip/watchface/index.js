﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_high_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_cal_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0_Fon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 173,
              y: 278,
              src: '0_BT_Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 266,
              y: 280,
              src: '0_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 322,
              y: 358,
              font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              padding: false,
              h_space: 0,
              invalid_image: '22.png',
              dot_image: '0_Del.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 336,
              y: 300,
              image_array: ["moon_00.png","moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 82,
              y: 300,
              image_array: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png","W_08.png","W_09.png","W_10.png","W_11.png","W_12.png","W_13.png","W_14.png","W_15.png","W_16.png","W_17.png","W_18.png","W_19.png","W_20.png","W_21.png","W_22.png","W_23.png","W_24.png","W_25.png","W_26.png","W_27.png","W_28.png","W_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 358,
              font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              padding: false,
              h_space: 0,
              unit_sc: '24.png',
              unit_tc: '24.png',
              unit_en: '24.png',
              negative_image: '23.png',
              invalid_image: '22.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 384,
              y: 235,
              font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 400,
              y: 92,
              image_array: ["53.png","54.png","55.png","56.png","57.png","58.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 37,
              y: 235,
              font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              padding: false,
              h_space: 0,
              invalid_image: '22.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 92,
              image_array: ["25.png","26.png","27.png","28.png","29.png","30.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 393,
              font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 148,
              y: 311,
              image_array: ["47.png","48.png","49.png","50.png","51.png","52.png"],
              image_length: 6,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 52,
              font_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 92,
              y: 5,
              image_array: ["41.png","42.png","43.png","44.png","45.png","46.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 269,
              month_startY: 95,
              month_sc_array: ["MS_01.png","MS_02.png","MS_03.png","MS_04.png","MS_05.png","MS_06.png","MS_07.png","MS_08.png","MS_09.png","MS_10.png","MS_11.png","MS_12.png"],
              month_tc_array: ["MS_01.png","MS_02.png","MS_03.png","MS_04.png","MS_05.png","MS_06.png","MS_07.png","MS_08.png","MS_09.png","MS_10.png","MS_11.png","MS_12.png"],
              month_en_array: ["MS_01.png","MS_02.png","MS_03.png","MS_04.png","MS_05.png","MS_06.png","MS_07.png","MS_08.png","MS_09.png","MS_10.png","MS_11.png","MS_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 141,
              y: 95,
              week_en: ["DN_01.png","DN_02.png","DN_03.png","DN_04.png","DN_05.png","DN_06.png","DN_07.png"],
              week_tc: ["DN_01.png","DN_02.png","DN_03.png","DN_04.png","DN_05.png","DN_06.png","DN_07.png"],
              week_sc: ["DN_01.png","DN_02.png","DN_03.png","DN_04.png","DN_05.png","DN_06.png","DN_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 95,
              day_sc_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              day_tc_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              day_en_array: ["31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 98,
              hour_startY: 150,
              hour_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 253,
              minute_startY: 150,
              minute_array: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 150,
              src: '11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 300,
              w: 127,
              h: 149,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 380,
              y: 105,
              w: 73,
              h: 166,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 290,
              w: 100,
              h: 100,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 97,
              y: 150,
              w: 117,
              h: 119,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 65,
              y: 290,
              w: 95,
              h: 115,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 98,
              y: 61,
              w: 269,
              h: 79,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 252,
              y: 150,
              w: 117,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}

        //#region Loading data from RuWeather
        function arrayBufferToCyrillic(buffer) {
          const bytes = new Uint8Array(buffer);
      const len = bytes.length;
      let chars = [];

      for (let i = 0; i < len;) {
        const byte1 = bytes[i];

        if (byte1 < 0x80) {
          chars.push(byte1);
          i += 1;
        } else if (byte1 >= 0xC0 && byte1 < 0xE0) {
          const byte2 = bytes[i + 1];
          const code = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
          chars.push(code);
          i += 2;
        } else if (byte1 >= 0xE0 && byte1 < 0xF0) {
          const byte2 = bytes[i + 1];
          const byte3 = bytes[i + 2];
          const code = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
          chars.push(code);
          i += 3;
        } else {
          // Skip invalid byte
          i++;
        }
      }

      // Вставка батчами для ускорения
      let result = '';
      const chunkSize = 1024;
      for (let j = 0; j < chars.length; j += chunkSize) {
        result += String.fromCharCode.apply(null, chars.slice(j, j + chunkSize));
      }

      return result;
        }
        function read_weather_data_str() {
          console.log('start read weather data');
          let str_result = "";
          try {
            const file_name = "weather.json";
            const mini_app_id = 1066654;

            const [fs_stat, err] = hmFS.stat(file_name, {
              appid: mini_app_id
            });
            if (err == 0) {
              //console.log('--->size_alt:', fs_stat.size);

              const fh = hmFS.open(file_name, hmFS.O_RDONLY, {
                appid: mini_app_id
              })

              const len = fs_stat.size;
              let array_buffer = new ArrayBuffer(len);
              hmFS.read(fh, array_buffer, 0, len);
              hmFS.close(fh);
              str_result = arrayBufferToCyrillic(array_buffer);
              //console.log(`str_result = ${str_result}`);
              return str_result;

            } else {
              console.log('err:', err)
            }

          } catch (error) {
            console.log('error:', error);
            console.log("FAIL: No access to hmFS.");
          }
          return "";
        }
        function getDataValue(str = "") {
          let value = 0;
          try {
            const data = JSON.parse(str); //получаем массив данных
            //присваиваем виджетам их значения
            normal_temperature_current_text_font.setProperty(hmUI.prop.TEXT, data.temperature + '°') //присваиваем виджетам их значения
            idle_temperature_current_text_font.setProperty(hmUI.prop.TEXT, data.temperature + '°')

            wCurTemp.setProperty(hmUI.prop.TEXT, data.temperature + '°(' + data.temperatureFeels + '°)')
            wCity.setProperty(hmUI.prop.TEXT, data.city)
            wUpdate.setProperty(hmUI.prop.TEXT, data.weatherTimeStr)

          } catch (error) {
            console.log('error:', error);
          }

        }

        function updateWeatherApp() {
          console.log('tick')
          let read_str = read_weather_data_str();
          getDataValue(read_str);
        }
        //#endregion